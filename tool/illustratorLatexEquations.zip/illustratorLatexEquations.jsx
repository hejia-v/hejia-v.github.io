﻿#target illustrator
var gui = new Window ('dialog', 'illustratorLatexEquations',undefined);

var outputFormatsArray = ['png','eps'];
var latexPreamble = '';
var latexBodyArray = new Array();

//The variable that hold the start URI of the output selection.
var outputFolderURI = null;

main();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function main(){
    try{
        gui.bounds={x:20,y:20,width:800,height:670};
        gui.graphics.font = ScriptUI.newFont ('Arial', ScriptUI.FontStyle.REGULAR, 16);
        gui.graphics.backgroundColor=gui.graphics.newBrush(gui.graphics.BrushType.SOLID_COLOR,[0.07,0.29,0.52],1);
        defineControls();
        //Loading the settings if they exist
        //output folder path
        var outParamFile = File(Folder.userData+'/illustratorLatexEquations/outputFolder.txt');
        if(outParamFile.exists){
            outParamFile.open('r');
            outputFolderURI=outParamFile.readln();
            outParamFile.close();
            }
        //latex preamble
        var latexPreambleFile = File(Folder.userData+'/illustratorLatexEquations/latexPreamble.txt');
        if(latexPreambleFile.exists){
            latexPreambleFile.open('r');
            latexPreamble=latexPreambleFile.read();
            latexPreambleFile.close();
            }
        else{
            initPreamble();
            latexPreambleFile.open('w');
            latexPreambleFile.write(latexPreamble);
            latexPreambleFile.close();
            }
        gui.show();
        }catch(e){
            alert('An error occured while initializing the user interface:\n'+e.toString());
            }
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    Initialization of the latexPreabmle variable
*/
function initPreamble(){
    //latexPreamble+='\\documentclass[12pt]{article}\n';
    latexPreamble+='\\documentclass[12pt]{article}\n';
    latexPreamble+='\\usepackage{amsmath}\n';
    latexPreamble+='\\usepackage{siunitx}\n';
    latexPreamble+='\\usepackage{xcolor}\n';
    latexPreamble+='\\usepackage[version=3]{mhchem}\n\n ';
    
    latexPreamble+='\\newcommand{\\degc}{^{\\circ}\\si{C}}\n';
    latexPreamble+='\\newcommand{\\difrac}[2]{\\displaystyle\\frac{#1}{#2}}\n';
    latexPreamble+='\\newcommand{\\pten}[2]{#1 \\times 10^{#2}}\n';
    latexPreamble+='\\newcommand{\\sinn}[1]{\\:\\si{#1}}\n';
    latexPreamble+='\\def\\D{\\text{d}}\n';
    latexPreamble+='\\def\\hsp5{\\hspace{0.5cm}}\n\n';
    
    latexPreamble+='\\definecolor{PB}{HTML}{134885}\n';
     
    latexPreamble+='\\everymath{\\color{PB}}\n';
    latexPreamble+='\\everydisplay{\\color{PB}}\n';
    latexPreamble+='\\color{PB}\n';
    
    latexPreamble+='\\sisetup{detect-all}\n';
    }
/*
    Populating the gui with controls and their event listeners
*/
function defineControls(){
    var fileIcon = getIcon('file');
    var settingIcon = getIcon('setting');
    var texIcon = getIcon('tex');
    if(fileIcon!=null && settingIcon!=null && texIcon!=null){
        gui.btn_openFile=gui.add("iconbutton", {x:5,y:5,width:50,height:50}, fileIcon, {style: "toolbutton"});
                gui.btn_openFile.onClick=showImportOptions;
        gui.btn_settings=gui.add("iconbutton", {x:70,y:5,width:50,height:50}, settingIcon, {style: "toolbutton"});
                gui.btn_settings.onClick=showGeneralSettings;
        gui.btn_texSettings=gui.add("iconbutton", {x:135,y:5,width:50,height:50}, texIcon, {style: "toolbutton"});
                gui.btn_texSettings.onClick=showLatexSettings;
        }
    gui.lb_latexBody=gui.add('listbox',{x:5,y:60,width:790,height:400},undefined);
            gui.lb_latexBody.graphics.backgroundColor=gui.lb_latexBody.graphics.newBrush(gui.lb_latexBody.graphics.BrushType.SOLID_COLOR,[0.16,0.37,0.60],1);
    
    gui.btn_editLatexBody=gui.add('button',{x:5,y:460,width:100,height:20},'Edit');
            gui.btn_editLatexBody.onClick=function(){
                if(gui.lb_latexBody.selection!=null && gui.lb_latexBody.selection.index>0){
                    var eqLine = gui.lb_latexBody.selection.text;
                    eqLine=eqLine.replace(/\\begin{equation\*}/gm,'\\begin{equation*}\n\t');
                    eqLine=eqLine.replace(/\\end{equation\*}/gm,'\n\\end{equation*}');
                    eqLine=eqLine.replace(/\\begin{subequations}/gm,'\\begin{subequations}\n');
                    eqLine=eqLine.replace(/\\begin{align\*}/,'\t\\begin{align*}\n\t\t\t');
                    eqLine=eqLine.replace(/\\end{align\*}/gm,'\n\t\\end{align*}\n');
                    eqLine=eqLine.replace(/\\\\/gm,'\\\\\n\t\t\t');
                    gui.tb_enterEq.text=eqLine;
                    }
                }
    gui.btn_removeLatexBody=gui.add('button',{x:110,y:460,width:100,height:20},'Remove');
            gui.btn_removeLatexBody.onClick=function(){
                if(gui.lb_latexBody.selection!=null && gui.lb_latexBody.selection.index>0){
                    latexBodyArray.splice(gui.lb_latexBody.selection.index,1);
                    gui.lb_latexBody.remove(gui.lb_latexBody.selection);
                    }
                }
    gui.btn_removeAllLatexBody=gui.add('button',{x:220,y:460,width:100,height:20},'Remove all');
            gui.btn_removeAllLatexBody.onClick=function(){
                    gui.lb_latexBody.removeAll();
                    latexBodyArray=new Array();
                }
    
    gui.progessBar=gui.add('progressbar',{x:5,y:490,width:790,height:10},undefined,undefined);
    gui.tb_enterEq=gui.add('edittext',{x:5,y:510,width:790,height:100},undefined,{multiline:true,scrollable:true});
            gui.tb_enterEq.text='\\begin{equation*}\n\n\\end{equation*}';
            gui.tb_enterEq.addEventListener('keydown',function(pKey){keyPressed(pKey);});
    gui.chb_subequations=gui.add('checkbox',{x:60,y:620,width:200,height:30},'Subequations with align');
            gui.chb_subequations.onClick = switchEquationMode;
    //gui.btn_createImages = gui.add('button',{x:300,y:620,width:200,height:30},'Genreate images');
            //gui.btn_createImages.onClick=function(){
                //deleteTex();
                //generateImages();
                //}
    //gui.btn_submit = gui.add('button',{x:5,y:610,width:170,height:30},'Submit');
    gui.btn_submit = gui.add("iconbutton", {x:5,y:610,width:50,height:50}, File(Folder.userData+'/illustratorLatexEquations/icon_ok.png'), {style: "toolbutton"});
            gui.btn_submit.onClick=submitEquation;
    gui.btn_play = gui.add("iconbutton", {x:730,y:610,width:50,height:50}, File(Folder.userData+'/illustratorLatexEquations/icon_play.png'), {style: "toolbutton"});
            gui.btn_play.onClick=play;
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    Handles gui.chb_subequations.onClick. It switched betweet text for an eqution tag and a text for a subequation tag
*/
function switchEquationMode(){
    if(gui.chb_subequations.value==true){
        gui.tb_enterEq.text='\\begin{subequations}\n\\begin{align*}\n\n\\end{align*}\n\\end{subequations}'
        }
    else{
        gui.tb_enterEq.text='\\begin{equation*}\n\n\\end{equation*}';
        }
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    Handles gui.tb_enterEq.addEventListener('keydown'). It checks it the comination SHIFT+ENTER was pressed. If so, it posts the equation in the ListBox
*/
function keyPressed(pKey){
    //if the combination SHIFT+ENTER is pressed submit the text
    if(pKey.keyIdentifier=='Enter' && pKey.shiftKey==true){
        submitEquation();
        }
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    Handles gui.btn_openFile.onClick. It displays a file selection tool used to navigate to the .txt file that holds the equations
*/
function showImportOptions(){
    try{
        var selectedFile = File.openDialog('Select the formated .txt file with the equations.','TEXT FILES:*.txt');
        if(selectedFile instanceof File){
            var uri = selectedFile.absoluteURI;
            if(uri.substring(uri.lastIndexOf('.')+1,uri.length)=='txt'){
                latexBodyArray = new Array();
                gui.lb_latexBody.removeAll();
                selectedFile.open('r');
                while(!selectedFile.eof){
                    var bLine = selectedFile.readln();
                    //subequations
                    if(bLine.substring(0,2)=='. '){
                        bLine = '\\begin{subequations}\\begin{align*}'+bLine.substring(2,bLine.length)+'\\end{align*}\\end{subequations}';
                        }
                    else{
                        bLine = '\\begin{equation*}'+bLine+'\\end{equation*}';
                        }
                    latexBodyArray.push(bLine);
                    addLatexBodyToList(bLine);
                    }
                selectedFile.close();
                }
            }
        else{alert('You did not select a file');}
        }catch(e){}
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    Handles gui.btn_editPreamble.onClick. It displays a paletter window in which Latex premable is to be edited
*/
function showLatexSettings(){
    var lsGUI =new Window('dialog','Edit LaTeX preamble',{x:120,y:120,width:400,height:400});
    
    lsGUI.tb_preamble=lsGUI.add('edittext',{x:5,y:5,width:390,height:350},undefined,{multiline:true,scrollable:true});
            lsGUI.tb_preamble.text= latexPreamble;
            
    lsGUI.btn_OK = lsGUI.add('button',{x:5,y:360,width:100,height:30},'OK');
            lsGUI.btn_OK.onClick=function(){
                latexPreamble=lsGUI.tb_preamble.text;
                var latexPreambleFile = File(Folder.userData+'/illustratorLatexEquations/latexPreamble.txt');
                latexPreambleFile.open('w');
                latexPreambleFile.write(latexPreamble);
                latexPreambleFile.close();
                lsGUI.close();
                }
    lsGUI.btn_CANCEL = lsGUI.add('button',{x:110,y:360,width:100,height:30},'CANCEL');
            lsGUI.btn_CANCEL.onClick=function(){
                lsGUI.close();
                }
            
    lsGUI.show();
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    Handles gui.btn_selectOutputFormats.onClick. It displays an palette window with the selection.
*/
function showGeneralSettings(){
     var gsGUI = new Window ('dialog', 'Select the output formats',{x:120,y:120,width:400,height:400});
     
     gsGUI.pnl_outputFormats=gsGUI.add('panel',{x:5,y:5,width:390,height:100},'Output formats')
             gsGUI.pnl_outputFormats.chb_png = gsGUI.pnl_outputFormats.add('checkbox',{x:5,y:5,width:50,height:20},'PNG');
                     gsGUI.pnl_outputFormats.chb_png.name='png';
                     gsGUI.pnl_outputFormats.chb_png.onClick=outputFormatChanged;
             gsGUI.pnl_outputFormats.chb_eps = gsGUI.pnl_outputFormats.add('checkbox',{x:5,y:25,width:50,height:20},'EPS');
                    gsGUI.pnl_outputFormats.chb_eps.name='eps'
                    gsGUI.pnl_outputFormats.chb_eps.onClick=outputFormatChanged;
             gsGUI.pnl_outputFormats.chb_ai = gsGUI.pnl_outputFormats.add('checkbox',{x:5,y:45,width:50,height:20},'AI');
                    gsGUI.pnl_outputFormats.chb_ai.name='ai'
                    gsGUI.pnl_outputFormats.chb_ai.onClick=outputFormatChanged;
             gsGUI.pnl_outputFormats.chb_pdf = gsGUI.pnl_outputFormats.add('checkbox',{x:75,y:5,width:50,height:20},'PDF');
                    gsGUI.pnl_outputFormats.chb_pdf.name='pdf'
                    gsGUI.pnl_outputFormats.chb_pdf.onClick=outputFormatChanged;
             gsGUI.pnl_outputFormats.chb_tex = gsGUI.pnl_outputFormats.add('checkbox',{x:75,y:25,width:50,height:20},'TEX');
                    gsGUI.pnl_outputFormats.chb_tex.name='tex'
                    gsGUI.pnl_outputFormats.chb_tex.onClick=outputFormatChanged;
             gsGUI.pnl_outputFormats.chb_jpeg = gsGUI.pnl_outputFormats.add('checkbox',{x:75,y:45,width:50,height:20},'JPEG');
                    gsGUI.pnl_outputFormats.chb_jpeg.name='jpeg'
                    gsGUI.pnl_outputFormats.chb_jpeg.onClick=outputFormatChanged;
             
     gsGUI.btn_selectOutputFolder = gsGUI.add('button',{x:5,y:110,width:150,height:30},'Select output folder');
            gsGUI.btn_selectOutputFolder.onClick=function(){
                var selectedFolder = Folder.selectDialog("Select folder");
                if(selectedFolder!=null){
                    outputFolderURI=selectedFolder.absoluteURI;
                    gsGUI.tb_outputFolder.text=outputFolderURI;
                    var outParamFile = File(Folder.userData+'/illustratorLatexEquations/outputFolder.txt');
                    outParamFile.open('w');
                    outParamFile.writeln(outputFolderURI);
                    outParamFile.close();
                    }
                };
     gsGUI.tb_outputFolder=gsGUI.add('statictext',{x:5,y:140,width:390,height:30},'null');
            gsGUI.tb_outputFolder.text=outputFolderURI;
     gsGUI.btn_OK=gsGUI.add('button',{x:5,y:190,width:80,height:30},'OK');
     gsGUI.btn_OK=gsGUI.add('button',{x:100,y:190,width:80,height:30},'CANCEL');
     
     for(var i=0;i<outputFormatsArray.length;i++){
         for(var j=0;j<gsGUI.pnl_outputFormats.children.length;j++){
             if(gsGUI.pnl_outputFormats.children[j].name==outputFormatsArray[i]){
                 gsGUI.pnl_outputFormats.children[j].value=true;
                 break;
                 }
             }
         }
     
     gsGUI.show();
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    Handles output format CheckBox click
*/
function outputFormatChanged(){
    try{
        if(this.value==true){
            outputFormatsArray.push(this.name);
            }
        else{
            if(outputFormatsArray.length==1){
                alert('You can not select no output formats.');
                this.value=true;
                }
            else{
                for(var i=0;i<outputFormatsArray.length;i++){
                    if(this.name==outputFormatsArray[i]){
                        outputFormatsArray.splice(i,1);
                        break;
                        }
                    }
                }
            }
        }catch(e){}
    }

/*
    Submits the entered equation
*/
function submitEquation(){
    try{
        var eqText = gui.tb_enterEq.text;
        //if a equation in the list is selcected, it will be replaced with this one
        if(gui.lb_latexBody.selection!=null && gui.lb_latexBody.selection.index>0){
            gui.lb_latexBody.items[gui.lb_latexBody.selection.index].text=eqText.replace(/(\r\n|\n|\r|\t)/gm,' ');
            latexBodyArray[gui.lb_latexBody.selection.index]=eqText.replace(/(\r\n|\n|\r|\t)/gm,' ');
            }
        else{
            latexBodyArray.push(eqText);
            addLatexBodyToList(eqText);
            }
        switchEquationMode();
        }catch(e){
            alert('An error occured while submitting an equation:\n'+e.toString());
            }
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    Accepts an equation String and inserts \t and \n. To use only before writing to the tex body.
    @return - returns the formated equation
*/
function formatTexEq(pEq){
    var equation = new String(pEq);
    try{
        equation=equation.replace(/\\begin{equation\*}/gm,'\\begin{equation*}\\n\\t');
        equation=equation.replace(/\\end{equation\*}/gm,'\\n\\end{equation*}');
        equation=equation.replace(/\\begin{subequations}/gm,'\\begin{subequations}\\n');
        equation=equation.replace(/\\begin{align\*}/,'\\t\\begin{align*}\\n\\t\\t\\t');
        equation=equation.replace(/\\end{align\*}/gm,'\\n\\t\\end{align*}\\n');
        equation=equation.replace(/\\\\/gm,'\\\\\\n\\t\\t\\t');
        equation=equation.replace(/\\end{subequations}/gm,'\\end{subequations}\\n');
        }catch(e){
            equation =pEq;
            }
    return equation;
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    Adds the latex body to the list to display
    @param pBody - String od the Latex body to be added
*/
function addLatexBodyToList(pBody){
    try{
        gui.lb_latexBody.add('item',pBody.replace(/(\r\n|\n|\r|\t)/gm,' '));
        }catch(e){}
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    @param pNode - the Node object that was expanded
    @return - returns the pNode path in the given TreeView object as a String
                  - in a case of an error, it returns null
*/
function getNodeTreeViewPath(pNode){
    var retVal = null;
    try{
        var ancestorsArray = new Array();
        var child = pNode;
        ancestorsArray.push(child);
        //populating the array with the parents of the pNode
        while(true){
            if(child.parent.text == undefined &&  child.parent.title != undefined){
                break;
                }
            else{
                ancestorsArray.push(child.parent);
                child = child.parent;
                }
            }
        //the ancestors need to be reversed to form a valid path
        ancestorsArray.reverse();
        retVal='';
        for(var i=0;i<ancestorsArray.length;i++){
            retVal+=ancestorsArray[i].text+'/';
            }
        //removing the last '/' char
        retVal = retVal.substring(0,retVal.length-1);
        }catch(e){
            retVal = null;
            alert('An error occured while getting the node TreeView path: '+e.toString());
            }
        if(retVal==undefined){retVal=null;}
        return retVal;
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    Populates the selected node item with the corresponding files from the folder
    @param pTreeView - TreeView control that holds the ListItem
    @param pNode - ListItem of type node to be populated
*/
function populateNode(pTreeView,pNode){
   // try{
        pNode.removeAll();
        var internalNodeURI=getNodeTreeViewPath(pNode);
        if(internalNodeURI!=null){
            switch(pTreeView.name){
                case 'tvOutputFolder':
                    outputFolderURI+='/'+internalNodeURI;
                    break;
                }
            var folder = Folder(outputFolderURI);
            var folderFiles=folder.getFiles();
            for(var i=0;i<folderFiles.length;i++){
                var folderItem=folderFiles[i];
               //if(folderItem instanceof File){
                    //if the treeview in question is the one that selects the input txt file it is to get the *.txt from the folder
                    //}
                if(folderItem instanceof Folder){
                    var listNode =pNode.add('node',folderItem.name);
                    var imgFile = getIcon('folder');
                    if(imgFile!=null){listNode.image=imgFile;}
                    }
                }
            }
        //}catch(e){}
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    Returns the icon png
    @param pName - the name of the icon type, for instance: folder, txt, png, eps, setting
    @return - returns an instance of File if it exists, otherwise null
*/
function getIcon(pName){
    var retVal = null;
    try{
        switch(pName){
            case 'folder':
                retVal = File(Folder.userData+'/illustratorLatexEquations/icon_folder_1.png');
                break;
            case 'setting':
                retVal = File(Folder.userData+'/illustratorLatexEquations/icon_setting.png');
                break;
            case 'file':
                retVal = File(Folder.userData+'/illustratorLatexEquations/icon_file.png');
                break;
            case 'tex':
                retVal = File(Folder.userData+'/illustratorLatexEquations/icon_tex.png');
                break;
            }
        if(!retVal.exists){retVal=null;}
    }catch(e){}
    if(retVal==undefined){retVal=null;}
    return retVal;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    Starts the procedure to create images of the equations
*/
function play(){
    generatePDF();
    deleteTex();
    generateImages();
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function generatePDF(){
    if(gui.lb_latexBody.items!=null){
        deleteFolderContents(outputFolderURI+'/generatedPDF');
        var step = true;
        //at least two output formats need to be created - PDF and TEX - both in one folder - tex files are to be deleted afterwards
        var oPdf = Folder(outputFolderURI+'/generatedPDF');oPdf.create();
        //output format folders creation
            for(var i=0;i<outputFormatsArray.length;i++){
                var oFolder = Folder(outputFolderURI+'/'+'output'+outputFormatsArray[i].toUpperCase());
                //if the folder does not exist create one
                if(!oFolder.exists){
                    try{oFolder.create;}
                    catch(e){
                        //if an error occurs break the creation and block operation by setting step to false
                        step=false;
                        break;
                        }
                    }
                //if the output folder already exists, iterate over its files deleting them
                else{
                    var oFolderEFiles=oFolder.getFiles();
                    for(var j=0;j<oFolderEFiles.length;j++){
                        try{
                            if(oFolderEFiles[j] instanceof File){
                                oFolderEFiles[j].remove();
                                }
                            }catch(e){}
                        }
                    try{oFolder.remove();}catch(e){}
                    }
                }
            if(step==true){
                //PDF and TEX generation 
                for(var i=0;i<gui.lb_latexBody.items.length;i++){
                    var latexBodyText = gui.lb_latexBody.items[i].text;
                    //TEX generation
                    var texFileG = File(oPdf.absoluteURI+'/'+'eq_'+i+'.tex');
                    texFileG.open('w');
                    texFileG.write(latexPreamble);
                    texFileG.writeln('\\begin{document}');
                    texFileG.writeln('\\pagestyle{empty}');
                    texFileG.write(latexBodyText+'');
                    texFileG.writeln('');
                    texFileG.writeln('\\end{document}');
                    texFileG.close();
                    var oldBatchFile = File(outputFolderURI+'/tex2pdf.bat');
                    if(oldBatchFile.exists){
                        oldBatchFile.remove();
                        }
                    try{
                        var batchFile = File(outputFolderURI+'/tex2pdf.bat');
                        var convertPath = outputFolderURI+'/generatedPDF';
                        convertPath=convertPath.substring(1,convertPath.length);
                        var driveLetter = convertPath.substring(0,convertPath.indexOf ('/'));
                        convertPath=convertPath.substring(convertPath.indexOf ('/'),convertPath.length);
                        driveLetter=driveLetter.toUpperCase();
                        convertPath=driveLetter+':'+convertPath.replace(/\//gm,'\\\\');
                        batchFile.open("w");
                        batchFile.writeln ('pdflatex.exe -output-directory="'+convertPath+'"'+' "'+convertPath+'\\eq_'+i+'.tex"');
                        //batchFile.writeln ('pdflatex.exe -output-directory="D:\\oDesk\\EducationAppsLtd\\Equations\\generatedPDF"'+' "D:\\oDesk\\EducationAppsLtd\\Equations\\generatedPDF\\eq_'+i+'.tex"');
                        batchFile.writeln('del "%~f0"&exit');
                        batchFile.close();
                        batchFile.execute();
                        while(batchFile.exists){}
                        }catch(e){alert('An error occured while generating the PDF');}
                    }
                }
            else{
                alert('There was an error while creating the output folders.');
                }       
        }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function deleteTex(){
    var texFolder = Folder(outputFolderURI+'/generatedPDF');
    var texFiles = texFolder.getFiles();
    for(var i=0;i<texFiles.length;i++){
        var fFile = texFiles[i];
        if(fFile instanceof File){
            var fExt = fFile.name.substring(fFile.name.lastIndexOf('.')+1,fFile.name.length);
            if(fExt!='pdf'){
                try{
                    fFile.remove();
                    }catch(e){alert('An error occured while deleting tex files:\n'+e.toString());}
                 }
            }
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function generateImages(){
    //output folder creation
    for(var j=0;j<outputFormatsArray.length;j++){
            var imgFolder = Folder(outputFolderURI+'/output'+outputFormatsArray[j].toUpperCase());
            if(imgFolder.exists){deleteFolderContents(imgFolder.absoluteURI);}
            else{imgFolder.create();}
            }
    //pdf file iteration       
    var pdfFilesFolder = Folder(outputFolderURI+'/generatedPDF');
    var pdfFiles = pdfFilesFolder.getFiles('*.pdf');
    for(var i=0;i<pdfFiles.length;i++){
        var pdfFile = pdfFiles[i];
        var docRef = openFile(pdfFile.absoluteURI);
        outlineDocText();
        fitArtboard();
        var wf = (app.activeDocument.geometricBounds[2]-app.activeDocument.geometricBounds[0])*1.2;
        if(wf>270){
            alert("Equation "+i+" width: "+wf);
            }
        //images generation
        for(var j=0;j<outputFormatsArray.length;j++){
            switch(outputFormatsArray[j]){
                case 'eps':
                    saveAsEps(outputFolderURI+'/outputEPS/'+pdfFile.name.substring(0,pdfFile.name.lastIndexOf('.'))+'.eps');
                    break;
                case 'png':
                    saveAsPng(outputFolderURI+'/outputPNG/'+pdfFile.name.substring(0,pdfFile.name.lastIndexOf('.'))+'.png');
                    break;
                }
            }
        app.activeDocument.close(SaveOptions.DONOTSAVECHANGES);
    }
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    @param pFile - path to the file as String
    @return - docReference
*/
function openFile(pFile){
    var fileToOpen = File(pFile);
    var docRef = app.open(fileToOpen);
    return docRef
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function fitArtboard() {
     app.activeDocument = documents[0];
     app.activeDocument.artboards[0].artboardRect = app.activeDocument.geometricBounds;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function outlineDocText() {  
          if ( app.documents.length == 0 ) return;  
  var docRef = app.activeDocument;  
          recurseLayers( docRef.layers );  
} 
function recurseLayers(objArray) {  
          for ( var i = 0; i < objArray.length; i++ ) {  
                    // Record previous value with conditional change  
                    var l = objArray[i].locked;  
                    if ( l ) objArray[i].locked = false;  
                    // Record previous value with conditional change  
                    var v = objArray[i].visible;  
                    if ( !v ) objArray[i].visible = true;  
                    outlineText( objArray[i].textFrames );  
                    // Recurse the contained layer collection  
                    if ( objArray[i].layers.length > 0 ) {  
                              recurseLayers( objArray[i].layers )  
                    }  
                    // Recurse the contained group collection  
                    if ( objArray[i].groupItems.length > 0 ) {  
                              recurseGroups( objArray[i].groupItems )  
                    }   
                    // Return to previous values  
                    objArray[i].locked = l;  
                    objArray[i].visible = v;  
          }  
}   
function recurseGroups(objArray) {  
          for ( var i = 0; i < objArray.length; i++ ) {  
                    // Record previous value with conditional change  
                    var l = objArray[i].locked;  
                    if ( l ) objArray[i].locked = false;  
                    // Record previous value with conditional change  
                    var h = objArray[i].hidden;  
                    if ( h ) objArray[i].hidden = false;  
                    outlineText( objArray[i].textFrames );  
                    // Recurse the contained group collection  
                    if ( objArray[i].groupItems.length > 0 ) {  
                              recurseGroups( objArray[i].groupItems )  
                    }   
                    // Return to previous values  
                    objArray[i].locked = l;  
                    objArray[i].hidden = h;  
          }  
} 
function outlineText(objArray) {  
          // Reverse this loop as it brakes the indexing  
          for ( var i = objArray.length-1; i >= 0; i-- ) {  
                    // Record previous value with conditional change  
                    var l = objArray[i].locked;  
                    if ( l ) objArray[i].locked = false;  
                    // Record previous value with conditional change  
                    var h = objArray[i].hidden;  
                    if ( h ) objArray[i].hidden = false;  
                    var g = objArray[i].createOutline(  );  
                    // Return new group to previous Text Frame values  
                    g.locked = l;  
                    g.hidden = h;  
          }  
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function saveAsEps(pPath) {
    var document = app.activeDocument;
    var docArtBoard = document.artboards[0];
    var epsFile = new File(pPath);
    var saveOpts = new EPSSaveOptions();
    saveOpts.cmykPostScript = true;
    saveOpts.embedAllFonts = true;
    document.saveAs(epsFile, saveOpts);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function saveAsPng(pPath){
    var document = app.activeDocument;
    var docArtBoard = document.artboards[0];
    var pngFile = new File(pPath);
	var options = new ExportOptionsPNG24();
	options.antiAliasing = true;
	options.transparency = true;
	//options.artBoardClipping = true;
    //100 (default scale) is 12px for 12pt font size, and 120 is 14px font
	options.verticalScale = 120;
	options.horizontalScale = 120;
	document.exportFile(pngFile, ExportType.PNG24, options);
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function deleteFolderContents(pFolderPath){
    try{
        var folder = Folder(pFolderPath);
        var folderFilesArray =  folder.getFiles();
        for(var i=0;folderFilesArray.length;i++){
           // if(folderFilesArray[i] instanceof File){
                folderFilesArray[i].remove();
                //}
            }
        }catch(e){}
    }